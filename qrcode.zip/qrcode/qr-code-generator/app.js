const express = require('express');
const qrcode = require('qrcode');
const app = express();
const port = 3000;

// Устанавливаем EJS как шаблонизатор
app.set('view engine', 'ejs');

// Middleware для обработки данных из формы
app.use(express.urlencoded({ extended: true }));

// Маршрут для главной страницы
app.get('/', (req, res) => {
    res.render('index', { qr: null });
});

// Маршрут для генерации QR-кода
app.post('/generate', (req, res) => {
    const text = req.body.text;

    qrcode.toDataURL(text, (err, url) => {
        if (err) {
            console.error(err);
            res.status(500).send('Ошибка при генерации QR-кода');
        } else {
            res.render('index', { qr: url });
        }
    });
});

// Запуск сервера
app.listen(port, () => {
    console.log(`Сервер запущен на http://localhost:${port}`);
});